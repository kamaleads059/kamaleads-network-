# Kamaleads Network — Books MLM Store

**Prophet Mark Kama · Kamaleads Ventures**

A full-stack MLM book store with a 5-level matrix commission system.

---

## Stack

- **Backend**: Node.js (ESM) + Express + SQLite (better-sqlite3) + JWT auth
- **Frontend**: React 18 + React Router v6 + Vite

---

## Quick Start

### 1. Install dependencies

```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

### 2. Run in development

Open two terminals:

```bash
# Terminal 1 — API (port 3001)
cd backend
npm start

# Terminal 2 — Frontend (port 5173)
cd frontend
npm run dev
```

Open **http://localhost:5173**

### 3. Production build

```bash
cd frontend
npm run build          # outputs to frontend/dist/

cd ../backend
node server.js         # API on port 3001
# Serve frontend/dist with nginx or a CDN
```

---

## Default Admin Login

```
Email:    admin@kamaleads.com
Password: admin1234
```

**Change the password immediately after first login.**

---

## MLM Commission Structure

| Level | Team Required | Earn per book sold |
|-------|--------------|-------------------|
| 1     | 5 members    | GH₵ 3.50          |
| 2     | 25 members   | GH₵ 3.50          |
| 3     | 125 members  | GH₵ 3.50          |
| 4     | 625 members  | GH₵ 3.50          |
| 5     | 3,125 members| GH₵ 3.50          |

- Book price: **GH₵ 70**
- Commission rate: **5% = GH₵ 3.50** per book
- Same commission on any book at any qualified level
- A seller must complete the team requirement to unlock that level's commissions

### How commissions flow

1. Seller A sells a book → earns GH₵ 3.50 directly
2. The system walks UP the referral chain
3. Each upline member who has **qualified their level** earns GH₵ 3.50 on that sale
4. Up to 5 levels deep

---

## API Endpoints

### Auth
```
POST /api/auth/register   { name, email, phone, password, referralCode }
POST /api/auth/login      { email, password }
GET  /api/auth/me
```

### Books
```
GET  /api/books
POST /api/books           (admin) { title, subtitle, author, price_ghc, description, cover_emoji }
PATCH /api/books/:id      (admin)
```

### Sales
```
POST /api/sales           { bookId, buyerName, buyerEmail, paymentRef }
GET  /api/sales/my
```

### Seller (authenticated)
```
GET /api/seller/dashboard
GET /api/seller/team
GET /api/seller/commissions
GET /api/seller/earnings-summary
```

### Admin (admin role only)
```
GET  /api/admin/overview
GET  /api/admin/sellers
GET  /api/admin/sellers/:id
PATCH /api/admin/sellers/:id
GET  /api/admin/commissions?status=pending&sellerId=xxx
POST /api/admin/commissions/payout       { sellerId }
POST /api/admin/commissions/payout-all
GET  /api/admin/reports/earnings
```

---

## Environment Variables

Create a `.env` file in `/backend`:

```env
PORT=3001
JWT_SECRET=your-very-secret-key-change-this
```

---

## Database

SQLite database auto-created at `backend/kamaleads.db` on first run.

Tables:
- `users` — sellers and admin accounts
- `books` — product catalogue
- `sales` — every recorded sale
- `commissions` — network commission entries (pending/paid)

---

## Deployment (VPS / Render / Railway)

1. Upload the full project to your server
2. Set environment variables
3. `cd backend && npm install && node server.js`
4. `cd frontend && npm install && npm run build`
5. Point nginx to `frontend/dist` for the frontend and proxy `/api/*` to port 3001

### Nginx config snippet

```nginx
server {
    listen 80;
    server_name kamaleads.com;

    root /var/www/kamaleads/frontend/dist;
    index index.html;

    location /api/ {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## Payment Integration (Next Step)

The "Buy Now" buttons on the store are ready for payment integration. 
Recommended for Ghana: **Paystack** or **MTN Mobile Money API**.

Steps:
1. Create a Paystack account at paystack.com
2. Add your secret key to `.env` as `PAYSTACK_SECRET`
3. Call Paystack's initialize endpoint when buyer clicks "Buy Now"
4. On payment confirmation webhook, call `POST /api/sales` automatically

---

## Brand

- **Primary Gold**: `#C9A84C`
- **Accent Red**: `#B8202A`
- **Background**: `#0D0D0D`
- **Fonts**: Cormorant Garamond (headings) + DM Sans (body)

---

*"She is worth far more than rubies." — Proverbs 31:10*

**Prophet Mark Kama · Kama Prayer Clinic · Kama Television · Kamaleads Ventures**
