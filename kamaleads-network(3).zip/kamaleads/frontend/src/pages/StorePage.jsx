import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';

const LEVELS = [
  { level: 1, required: 5, members: '5' },
  { level: 2, required: 25, members: '25' },
  { level: 3, required: 125, members: '125' },
  { level: 4, required: 625, members: '625' },
  { level: 5, required: 3125, members: '3,125' },
];

export default function StorePage() {
  const [books, setBooks] = useState([]);
  const [searchParams] = useSearchParams();
  const refCode = searchParams.get('ref');

  useEffect(() => {
    api.getBooks().then(setBooks).catch(() => {
      setBooks([
        { id: 'book-woman', title: 'Woman', subtitle: 'The Hidden Treasure', author: 'Prophet Mark Kama', price_ghc: 70, commission_pct: 5, cover_emoji: '💎', description: 'Uncovering the priceless value, strength, and divine purpose of every woman.' },
        { id: 'book-man', title: 'Man', subtitle: 'Built of Iron', author: 'Prophet Mark Kama', price_ghc: 70, commission_pct: 5, cover_emoji: '⚔️', description: 'Forging character, purpose, and divine strength in every man.' },
      ]);
    });
  }, []);

  return (
    <div>
      {/* Hero */}
      <section style={{
        background: 'var(--surface)',
        borderBottom: '0.5px solid var(--border)',
        padding: '4rem 2rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.04,
          backgroundImage: 'repeating-linear-gradient(45deg, var(--gold) 0, var(--gold) 1px, transparent 0, transparent 50%)',
          backgroundSize: '30px 30px',
        }} />
        <div style={{ position: 'relative' }}>
          <div className="label" style={{ marginBottom: 12 }}>✦ Kamaleads Ventures ✦</div>
          <h1 style={{ marginBottom: 12, lineHeight: 1.2 }}>
            Books That <span className="gold">Transform</span> Lives
          </h1>
          <p style={{ color: 'var(--muted)', maxWidth: 520, margin: '0 auto 2rem', fontSize: 15, lineHeight: 1.8 }}>
            Spirit-filled literature from Prophet Mark Kama. Join our network, share the message, and earn commissions on every sale.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to={`/register${refCode ? `?ref=${refCode}` : ''}`} className="btn btn-gold">
              Become a Seller ✦
            </Link>
            <a href="#books" className="btn btn-outline">Browse Books</a>
          </div>
          {refCode && (
            <div style={{ marginTop: 16, fontSize: 12, color: 'var(--gold)', opacity: 0.8 }}>
              You were referred by code: <strong>{refCode}</strong>
            </div>
          )}
        </div>
      </section>

      {/* Books */}
      <section id="books" style={{ padding: '3rem 2rem' }}>
        <div className="label" style={{ marginBottom: 20, textAlign: 'center' }}>Featured Books</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', maxWidth: 900, margin: '0 auto' }}>
          {books.map(book => <BookCard key={book.id} book={book} />)}
        </div>
      </section>

      {/* MLM Plan */}
      <section style={{ padding: '3rem 2rem', background: 'var(--surface)', borderTop: '0.5px solid var(--border)' }}>
        <div style={{ maxWidth: 800, margin: '0 auto' }}>
          <div className="label" style={{ marginBottom: 8, textAlign: 'center' }}>Compensation Plan</div>
          <h2 style={{ textAlign: 'center', marginBottom: 8 }}>The 5 × Matrix</h2>
          <p style={{ textAlign: 'center', color: 'var(--muted)', marginBottom: 2.5 + 'rem', fontSize: 14 }}>
            Earn <span className="gold">GH₵ 3.50 (5%)</span> on every book sold at each level you qualify for
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 10 }}>
            {LEVELS.map(l => (
              <div key={l.level} className="card" style={{ textAlign: 'center', padding: '1rem 0.75rem' }}>
                <div className="label" style={{ marginBottom: 6 }}>Level {l.level}</div>
                <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 28, color: 'var(--gold)', lineHeight: 1 }}>{l.members}</div>
                <div style={{ fontSize: 11, color: 'var(--muted)', margin: '4px 0' }}>team members</div>
                <div style={{ fontSize: 12, color: 'var(--gold)', marginTop: 6 }}>
                  GH₵ {(3.5 * l.required).toLocaleString()} / book cycle
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: '2rem', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            {[
              { icon: '✦', t: '5% on every sale', s: 'GH₵ 3.50 per book at any level' },
              { icon: '✦', t: 'Recruit & grow', s: 'Build your team 5 levels deep' },
              { icon: '✦', t: 'Any book earns', s: 'Same rate across all titles' },
            ].map(f => (
              <div key={f.t} className="card-dark" style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <span style={{ color: 'var(--gold)', fontSize: 16 }}>{f.icon}</span>
                <div>
                  <div style={{ fontWeight: 500, fontSize: 14, marginBottom: 3 }}>{f.t}</div>
                  <div style={{ color: 'var(--muted)', fontSize: 13 }}>{f.s}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <Link to="/register" className="btn btn-gold">Join the Network — Free →</Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '2rem', borderTop: '0.5px solid var(--border)', textAlign: 'center' }}>
        <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 18, color: 'var(--gold)', marginBottom: 4 }}>Kamaleads Ventures</div>
        <div style={{ fontSize: 12, color: 'var(--muted)' }}>Kama Prayer Clinic · Kama Television · @prophetmarkkama</div>
        <div style={{ fontSize: 11, color: 'var(--faint)', marginTop: 8 }}>
          "She is worth far more than rubies." — Proverbs 31:10
        </div>
      </footer>
    </div>
  );
}

function BookCard({ book }) {
  const covers = {
    '💎': { bg: 'linear-gradient(145deg,#1a0808,#2d1010)', accent: '#8B0000' },
    '⚔️': { bg: 'linear-gradient(145deg,#08091a,#101228)', accent: '#1a1a5a' },
  };
  const style = covers[book.cover_emoji] || { bg: 'var(--surface2)', accent: '#333' };

  return (
    <div className="card" style={{ overflow: 'hidden', padding: 0 }}>
      <div style={{
        background: style.bg, height: 180,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 8,
        borderBottom: `1px solid ${style.accent}`,
      }}>
        <div style={{ fontSize: 40, opacity: 0.7 }}>{book.cover_emoji}</div>
        <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 22, color: 'var(--gold)', textAlign: 'center', padding: '0 1rem' }}>
          {book.title}
        </div>
        <div style={{ fontSize: 12, color: 'rgba(201,168,76,0.55)', letterSpacing: 0.5 }}>{book.subtitle}</div>
      </div>
      <div style={{ padding: '1rem 1.25rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
          <div>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 24, color: 'var(--gold)' }}>GH₵ {book.price_ghc}</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }}>eBook · instant download</div>
          </div>
          <span className="badge badge-gold">Earn GH₵ 3.50</span>
        </div>
        <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12, lineHeight: 1.7 }}>{book.description}</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-gold" style={{ flex: 1 }} onClick={() => alert('Payment integration: connect MTN Mobile Money or Paystack here')}>
            Buy Now
          </button>
          <Link to="/register" className="btn btn-outline" style={{ flex: 1 }}>Sell & Earn</Link>
        </div>
      </div>
    </div>
  );
}
