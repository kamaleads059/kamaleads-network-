import { useEffect, useState, useCallback } from 'react';
import { api } from '../lib/api.js';

const TABS = ['Overview', 'Sellers', 'Commissions', 'Reports', 'Books'];

export default function AdminDashboard() {
  const [tab, setTab] = useState('Overview');
  const [overview, setOverview] = useState(null);
  const [sellers, setSellers] = useState(null);
  const [comms, setComms] = useState(null);
  const [reports, setReports] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadOverview = useCallback(() => {
    setLoading(true);
    api.getAdminOverview().then(d => { setOverview(d); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  useEffect(() => { loadOverview(); }, [loadOverview]);

  useEffect(() => {
    if (tab === 'Sellers' && !sellers) api.getAdminSellers().then(setSellers).catch(console.error);
    if (tab === 'Commissions' && !comms) api.getAdminCommissions().then(setComms).catch(console.error);
    if (tab === 'Reports' && !reports) api.getReports().then(setReports).catch(console.error);
  }, [tab]);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 300, color: 'var(--muted)' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 28, color: 'var(--gold)', marginBottom: 8 }}>✦</div>
        Loading admin panel…
      </div>
    </div>
  );

  return (
    <div>
      <div className="page-header" style={{ background: 'linear-gradient(135deg, var(--surface) 0%, #1a1208 100%)', borderBottom: '2px solid var(--gold)' }}>
        <div className="label">Admin — Prophet Mark Kama</div>
        <h2>Network Command Centre</h2>
        {overview && (
          <div style={{ display: 'flex', gap: '1.5rem', marginTop: 10 }}>
            <QuickStat label="Total Sellers" value={overview.sellers} />
            <QuickStat label="Books Sold" value={overview.totalSales?.c?.toLocaleString() || 0} />
            <QuickStat label="Revenue" value={`GH₵ ${Number(overview.totalSales?.rev || 0).toLocaleString()}`} />
            <QuickStat label="Pending Payouts" value={`GH₵ ${Number(overview.pendingComms || 0).toFixed(0)}`} highlight />
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 2, padding: '0.75rem 2rem 0', borderBottom: '0.5px solid var(--border)', overflowX: 'auto' }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            background: tab === t ? 'var(--gold-dim)' : 'transparent',
            color: tab === t ? 'var(--gold)' : 'var(--muted)',
            border: tab === t ? '0.5px solid var(--gold-border)' : '0.5px solid transparent',
            borderBottom: 'none', borderRadius: '6px 6px 0 0',
            padding: '7px 16px', fontSize: 12, cursor: 'pointer',
            fontFamily: 'DM Sans, sans-serif', whiteSpace: 'nowrap'
          }}>{t}</button>
        ))}
      </div>

      <div className="section">
        {tab === 'Overview' && <OverviewTab d={overview} onRefresh={loadOverview} />}
        {tab === 'Sellers' && <SellersTab sellers={sellers} onRefresh={() => { setSellers(null); api.getAdminSellers().then(setSellers); }} />}
        {tab === 'Commissions' && (
          <CommissionsTab comms={comms}
            onRefresh={() => { setComms(null); api.getAdminCommissions().then(setComms); }}
            onPayoutAll={async () => { await api.payoutAll(); setComms(null); api.getAdminCommissions().then(setComms); loadOverview(); }} />
        )}
        {tab === 'Reports' && <ReportsTab reports={reports} />}
        {tab === 'Books' && <BooksTab />}
      </div>
    </div>
  );
}

function QuickStat({ label, value, highlight }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 1 }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 500, color: highlight ? 'var(--gold)' : 'var(--white)' }}>{value}</div>
    </div>
  );
}

// ─── Overview ─────────────────────────────────────────────────────────────────
function OverviewTab({ d, onRefresh }) {
  if (!d) return null;
  const { topSellers, recentSales, networkLevelStats, salesThisMonth, newSellersThisWeek } = d;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '1rem' }}>
        <button className="btn btn-ghost btn-sm" onClick={onRefresh}>↻ Refresh</button>
      </div>

      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'New Sellers (7 days)', value: newSellersThisWeek, sub: 'recent sign-ups' },
          { label: 'Sales This Month', value: salesThisMonth?.c || 0, sub: `GH₵ ${Number(salesThisMonth?.rev || 0).toFixed(0)} revenue` },
          { label: 'Commissions Paid', value: `GH₵ ${Number(d.paidComms || 0).toFixed(0)}`, sub: 'all time' },
          { label: 'Pending Payouts', value: `GH₵ ${Number(d.pendingComms || 0).toFixed(0)}`, sub: 'awaiting payment' },
        ].map(s => (
          <div key={s.label} className="card">
            <div className="stat-label-sm" style={{ marginBottom: 6 }}>{s.label}</div>
            <div className="stat-num" style={{ fontSize: '1.5rem' }}>{s.value}</div>
            <div className="stat-label-sm" style={{ marginTop: 3 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Network Level Stats */}
      <div className="label" style={{ marginBottom: 12 }}>Network by Level</div>
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {(networkLevelStats || []).map(l => (
          <div key={l.level} className="card">
            <div className="label" style={{ marginBottom: 6 }}>Level {l.level}</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{l.qualified} qualified</span>
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>need {l.required.toLocaleString()}</span>
            </div>
            <div className="progress-track">
              <div className="progress-fill" style={{ width: Math.min(100, l.total_sellers / l.required * 100) + '%' }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
        {/* Top Sellers */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '1rem 1.25rem', borderBottom: '0.5px solid var(--border)' }}>
            <div className="label">Top Sellers</div>
          </div>
          <table>
            <thead><tr><th>#</th><th>Name</th><th>Sales</th><th>Revenue</th></tr></thead>
            <tbody>{(topSellers || []).map((s, i) => (
              <tr key={s.id}>
                <td style={{ color: 'var(--gold)', fontWeight: 500 }}>{i + 1}</td>
                <td>{s.name}</td>
                <td>{s.sales_count}</td>
                <td className="gold">GH₵ {Number(s.revenue).toFixed(0)}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>

        {/* Recent Sales */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '1rem 1.25rem', borderBottom: '0.5px solid var(--border)' }}>
            <div className="label">Recent Sales</div>
          </div>
          <table>
            <thead><tr><th>Seller</th><th>Book</th><th>Amount</th><th>Date</th></tr></thead>
            <tbody>{(recentSales || []).slice(0, 8).map(s => (
              <tr key={s.id}>
                <td>{s.seller_name}</td>
                <td style={{ color: 'var(--muted)' }}>{s.cover_emoji} {s.book_title}</td>
                <td className="gold">GH₵ {s.amount_ghc}</td>
                <td style={{ color: 'var(--muted)' }}>{s.created_at?.slice(0, 10)}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Sellers ──────────────────────────────────────────────────────────────────
function SellersTab({ sellers, onRefresh }) {
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);

  if (!sellers) return <div style={{ color: 'var(--muted)' }}>Loading…</div>;

  const filtered = sellers.filter(s =>
    (s.name + s.email + s.referral_code).toLowerCase().includes(search.toLowerCase())
  );

  async function openDetail(seller) {
    setSelected(seller);
    const d = await api.getAdminSeller(seller.id);
    setDetail(d);
  }

  async function payout(sellerId) {
    await api.payoutSeller(sellerId);
    onRefresh();
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 380px' : '1fr', gap: '1.25rem' }}>
      <div>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem', alignItems: 'center' }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search sellers…" style={{ maxWidth: 300 }} />
          <span style={{ fontSize: 12, color: 'var(--muted)' }}>{filtered.length} sellers</span>
          <button className="btn btn-ghost btn-sm" onClick={onRefresh}>↻</button>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table>
            <thead><tr><th>Name</th><th>Code</th><th>Team</th><th>Levels</th><th>Sales</th><th>Revenue</th><th>Joined</th><th></th></tr></thead>
            <tbody>{filtered.map(s => (
              <tr key={s.id} style={{ cursor: 'pointer' }} onClick={() => openDetail(s)}>
                <td>
                  <div>{s.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>{s.email}</div>
                </td>
                <td><span className="badge badge-gold">{s.referral_code}</span></td>
                <td>{s.team_size}</td>
                <td>
                  {s.qualified_levels?.length > 0
                    ? s.qualified_levels.map(l => <span key={l} className="badge badge-green" style={{ marginRight: 2, fontSize: 10 }}>L{l}</span>)
                    : <span style={{ color: 'var(--muted)', fontSize: 11 }}>none</span>}
                </td>
                <td>{s.sales_count}</td>
                <td className="gold">GH₵ {Number(s.revenue).toFixed(0)}</td>
                <td style={{ color: 'var(--muted)' }}>{s.created_at?.slice(0, 10)}</td>
                <td onClick={e => { e.stopPropagation(); payout(s.id); }}>
                  <button className="btn btn-ghost btn-sm">Pay out</button>
                </td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>

      {selected && (
        <div className="card" style={{ position: 'sticky', top: 80, alignSelf: 'start' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <div className="label">Seller Detail</div>
            <button className="btn btn-ghost btn-sm" onClick={() => { setSelected(null); setDetail(null); }}>✕</button>
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 20, marginBottom: 2 }}>{selected.name}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>{selected.email}</div>
            {selected.phone && <div style={{ fontSize: 12, color: 'var(--muted)' }}>{selected.phone}</div>}
            <div style={{ marginTop: 6 }}><span className="badge badge-gold">{selected.referral_code}</span></div>
          </div>
          <div className="divider" />
          {detail ? (
            <>
              <div className="grid-2" style={{ marginBottom: '1rem', gap: 8 }}>
                <div className="card-dark"><div className="stat-label-sm">Sales</div><div style={{ fontSize: 20, color: 'var(--gold)' }}>{detail.sales?.length || 0}</div></div>
                <div className="card-dark"><div className="stat-label-sm">Team</div><div style={{ fontSize: 20, color: 'var(--gold)' }}>{detail.teamStats?.total || 0}</div></div>
              </div>
              <div className="label" style={{ marginBottom: 8 }}>Level Progress</div>
              {[1,2,3,4,5].map(l => {
                const req = [5,25,125,625,3125][l-1];
                const have = detail.teamStats?.byLevel?.[l] || 0;
                return (
                  <div key={l} style={{ marginBottom: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 3 }}>
                      <span style={{ color: 'var(--muted)' }}>Level {l}</span>
                      <span style={{ color: 'var(--muted)' }}>{have}/{req}</span>
                    </div>
                    <div className="progress-track">
                      <div className="progress-fill" style={{ width: Math.min(100, have/req*100) + '%' }} />
                    </div>
                  </div>
                );
              })}
              <button className="btn btn-gold btn-sm btn-full" style={{ marginTop: '1rem' }} onClick={() => payout(selected.id)}>
                Pay All Pending Commissions
              </button>
            </>
          ) : <div style={{ color: 'var(--muted)', fontSize: 12 }}>Loading detail…</div>}
        </div>
      )}
    </div>
  );
}

// ─── Commissions ──────────────────────────────────────────────────────────────
function CommissionsTab({ comms, onRefresh, onPayoutAll }) {
  const [filter, setFilter] = useState('all');
  const [paying, setPaying] = useState(false);

  if (!comms) return <div style={{ color: 'var(--muted)' }}>Loading…</div>;

  const pending = comms.filter(c => c.status === 'pending');
  const paid = comms.filter(c => c.status === 'paid');
  const shown = filter === 'pending' ? pending : filter === 'paid' ? paid : comms;
  const pendingTotal = pending.reduce((a, c) => a + c.amount_ghc, 0);
  const paidTotal = paid.reduce((a, c) => a + c.amount_ghc, 0);

  async function handlePayoutAll() {
    if (!confirm(`Pay out all ${pending.length} pending commissions (GH₵ ${pendingTotal.toFixed(2)})?`)) return;
    setPaying(true);
    await onPayoutAll();
    setPaying(false);
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="card" style={{ flex: 1, minWidth: 140 }}>
          <div className="stat-label-sm">Pending</div>
          <div className="stat-num" style={{ fontSize: '1.4rem' }}>GH₵ {pendingTotal.toFixed(2)}</div>
          <div className="stat-label-sm">{pending.length} transactions</div>
        </div>
        <div className="card" style={{ flex: 1, minWidth: 140 }}>
          <div className="stat-label-sm">Paid out</div>
          <div className="stat-num" style={{ fontSize: '1.4rem', color: '#4caf7d' }}>GH₵ {paidTotal.toFixed(2)}</div>
          <div className="stat-label-sm">{paid.length} transactions</div>
        </div>
        {pending.length > 0 && (
          <button className="btn btn-gold" onClick={handlePayoutAll} disabled={paying}>
            {paying ? 'Processing…' : `Pay All (GH₵ ${pendingTotal.toFixed(2)})`}
          </button>
        )}
        <button className="btn btn-ghost btn-sm" onClick={onRefresh}>↻ Refresh</button>
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1rem' }}>
        {[['all', `All (${comms.length})`], ['pending', `Pending (${pending.length})`], ['paid', `Paid (${paid.length})`]].map(([v, l]) => (
          <button key={v} className={`btn btn-sm ${filter === v ? 'btn-gold' : 'btn-ghost'}`} onClick={() => setFilter(v)}>{l}</button>
        ))}
      </div>

      <div className="card" style={{ padding: 0 }}>
        {shown.length === 0
          ? <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)' }}>No commissions found.</div>
          : <table>
              <thead><tr><th>Seller</th><th>Book (sold by)</th><th>Level</th><th>Amount</th><th>Status</th><th>Date</th><th></th></tr></thead>
              <tbody>{shown.map(c => (
                <tr key={c.id}>
                  <td>
                    <div>{c.seller_name}</div>
                    <div style={{ fontSize: 11, color: 'var(--muted)' }}>{c.seller_phone || c.seller_email}</div>
                  </td>
                  <td style={{ color: 'var(--muted)' }}>
                    <div>{c.cover_emoji} {c.book_title}</div>
                    <div style={{ fontSize: 11 }}>via {c.sale_seller_name}</div>
                  </td>
                  <td><span className="badge badge-gold">L{c.level}</span></td>
                  <td className="gold">GH₵ {c.amount_ghc}</td>
                  <td><span className={`badge ${c.status === 'paid' ? 'badge-green' : 'badge-muted'}`}>{c.status}</span></td>
                  <td style={{ color: 'var(--muted)' }}>{c.created_at?.slice(0, 10)}</td>
                  <td>
                    {c.status === 'pending' && (
                      <button className="btn btn-ghost btn-sm" onClick={async () => {
                        await api.payoutSeller(c.seller_id); onRefresh();
                      }}>Pay</button>
                    )}
                  </td>
                </tr>
              ))}</tbody>
            </table>
        }
      </div>
    </div>
  );
}

// ─── Reports ──────────────────────────────────────────────────────────────────
function ReportsTab({ reports }) {
  if (!reports) return <div style={{ color: 'var(--muted)' }}>Loading…</div>;
  const { monthly, byBook } = reports;

  const maxRev = Math.max(...(monthly || []).map(m => m.revenue), 1);

  return (
    <div>
      <div className="label" style={{ marginBottom: 12 }}>Revenue by Book</div>
      <div className="grid-2" style={{ marginBottom: '2rem' }}>
        {(byBook || []).map(b => (
          <div key={b.title} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 500 }}>{b.cover_emoji} {b.title}: {b.subtitle}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>{b.sales} sales</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="gold" style={{ fontSize: 18, fontWeight: 500 }}>GH₵ {Number(b.revenue).toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="label" style={{ marginBottom: 12 }}>Monthly Revenue</div>
      <div className="card" style={{ padding: 0, marginBottom: '1.5rem' }}>
        <table>
          <thead><tr><th>Month</th><th>Sales</th><th>Revenue</th><th>Bar</th></tr></thead>
          <tbody>{(monthly || []).map(m => (
            <tr key={m.month}>
              <td>{m.month}</td>
              <td>{m.sales}</td>
              <td className="gold">GH₵ {Number(m.revenue).toLocaleString()}</td>
              <td style={{ width: 200 }}>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: (m.revenue / maxRev * 100) + '%' }} />
                </div>
              </td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Books ────────────────────────────────────────────────────────────────────
function BooksTab() {
  const [books, setBooks] = useState([]);
  const [form, setForm] = useState({ title: '', subtitle: '', author: 'Prophet Mark Kama', price_ghc: 70, description: '', cover_emoji: '📖' });
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { api.getBooks().then(setBooks); }, []);

  async function addBook(e) {
    e.preventDefault();
    setMsg(''); setError('');
    try {
      await api.addBook(form);
      setMsg('✦ Book added successfully');
      setForm(f => ({ ...f, title: '', subtitle: '', description: '' }));
      api.getBooks().then(setBooks);
    } catch (err) { setError(err.message); }
  }

  async function toggleActive(book) {
    await api.updateBook(book.id, { active: book.active ? 0 : 1 });
    api.getBooks().then(setBooks);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
      <div>
        <div className="label" style={{ marginBottom: 12 }}>Current Books</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {books.map(b => (
            <div key={b.id} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 500 }}>{b.cover_emoji} {b.title}: {b.subtitle}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 3 }}>
                  GH₵ {b.price_ghc} · {b.commission_pct}% commission · earn GH₵ {(b.price_ghc * b.commission_pct / 100).toFixed(2)}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                <span className={`badge ${b.active ? 'badge-green' : 'badge-red'}`}>{b.active ? 'Active' : 'Hidden'}</span>
                <button className="btn btn-ghost btn-sm" onClick={() => toggleActive(b)}>
                  {b.active ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="label" style={{ marginBottom: 12 }}>Add New Book</div>
        <div className="card">
          {msg && <div className="success-msg">{msg}</div>}
          {error && <div className="error-msg">{error}</div>}
          <form onSubmit={addBook}>
            <div className="form-group"><label className="form-label">Title *</label><input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required /></div>
            <div className="form-group"><label className="form-label">Subtitle</label><input value={form.subtitle} onChange={e => setForm(f => ({ ...f, subtitle: e.target.value }))} /></div>
            <div className="form-group"><label className="form-label">Author</label><input value={form.author} onChange={e => setForm(f => ({ ...f, author: e.target.value }))} /></div>
            <div className="form-group"><label className="form-label">Price (GH₵) *</label><input type="number" value={form.price_ghc} onChange={e => setForm(f => ({ ...f, price_ghc: +e.target.value }))} required /></div>
            <div className="form-group"><label className="form-label">Cover emoji</label><input value={form.cover_emoji} onChange={e => setForm(f => ({ ...f, cover_emoji: e.target.value }))} /></div>
            <div className="form-group"><label className="form-label">Description</label><textarea rows={3} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} style={{ resize: 'vertical' }} /></div>
            <button type="submit" className="btn btn-gold btn-full">Add Book</button>
          </form>
        </div>
      </div>
    </div>
  );
}
