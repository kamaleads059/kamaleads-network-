import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api, saveAuth } from '../lib/api.js';
import { useAuth } from '../App.jsx';

export default function RegisterPage() {
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState({
    name: '', email: '', phone: '', password: '',
    referralCode: searchParams.get('ref') || '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const { token, user } = await api.register(form);
      saveAuth(token, user);
      login(user);
      navigate('/seller');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ minHeight: 'calc(100vh - 60px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <div style={{ width: '100%', maxWidth: 440 }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div className="label" style={{ marginBottom: 8 }}>✦ Free to Join ✦</div>
          <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 34, color: 'var(--gold)', marginBottom: 4 }}>Become a Seller</div>
          <div style={{ color: 'var(--muted)', fontSize: 14 }}>Earn GH₵ 3.50 on every book you sell</div>
        </div>

        <div className="card">
          {error && <div className="error-msg">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full name</label>
              <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Your full name" required />
            </div>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="you@example.com" required />
            </div>
            <div className="form-group">
              <label className="form-label">Phone / WhatsApp</label>
              <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+233 XX XXX XXXX" />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="Minimum 8 characters" required minLength={6} />
            </div>
            <div className="form-group">
              <label className="form-label">Referral code (optional)</label>
              <input value={form.referralCode} onChange={e => setForm(f => ({ ...f, referralCode: e.target.value }))} placeholder="e.g. KAMA0001" />
            </div>
            <button type="submit" className="btn btn-gold btn-full" disabled={loading} style={{ marginTop: 8 }}>
              {loading ? 'Creating account…' : 'Activate Seller Account →'}
            </button>
          </form>

          <div className="divider" />
          <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--muted)' }}>
            Already a seller? <Link to="/login">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
