import { useEffect, useState, useCallback } from 'react';
import { api } from '../lib/api.js';
import { useAuth } from '../App.jsx';

const LEVELS = [
  { level: 1, required: 5 },
  { level: 2, required: 25 },
  { level: 3, required: 125 },
  { level: 4, required: 625 },
  { level: 5, required: 3125 },
];

const TABS = ['Overview', 'My Team', 'Sales', 'Commissions', 'Earnings', 'Record Sale'];

export default function SellerDashboard() {
  const { user } = useAuth();
  const [tab, setTab] = useState('Overview');
  const [data, setData] = useState(null);
  const [team, setTeam] = useState(null);
  const [sales, setSales] = useState(null);
  const [comms, setComms] = useState(null);
  const [earnings, setEarnings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const loadDashboard = useCallback(() => {
    setLoading(true);
    api.getDashboard()
      .then(d => { setData(d); setLoading(false); })
      .catch(e => { setError(e.message); setLoading(false); });
  }, []);

  useEffect(() => { loadDashboard(); }, [loadDashboard]);

  useEffect(() => {
    if (tab === 'My Team' && !team) api.getTeam().then(setTeam).catch(console.error);
    if (tab === 'Sales' && !sales) api.getMySales().then(setSales).catch(console.error);
    if (tab === 'Commissions' && !comms) api.getCommissions().then(setComms).catch(console.error);
    if (tab === 'Earnings' && !earnings) api.getEarningsSummary().then(setEarnings).catch(console.error);
  }, [tab]);

  function copyRef() {
    navigator.clipboard.writeText(data?.referralLink || '').catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 300, color: 'var(--muted)' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 28, color: 'var(--gold)', marginBottom: 8 }}>✦</div>
        Loading your dashboard…
      </div>
    </div>
  );

  if (error) return (
    <div style={{ padding: '2rem' }}>
      <div className="error-msg">{error}</div>
      <button className="btn btn-outline" onClick={loadDashboard}>Retry</button>
    </div>
  );

  const d = data || {};
  const stats = d.stats || {};
  const teamStats = d.teamStats || { total: 0, byLevel: {}, qualifiedLevels: [], nextProgress: null };

  return (
    <div>
      <div className="page-header" style={{ background: 'var(--surface)' }}>
        <div className="label">Seller Portal</div>
        <h2 style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          Welcome back, {(user?.name || d.user?.name || '').split(' ')[0]}
          <span style={{ fontSize: 13, color: 'var(--muted)', fontFamily: 'DM Sans', fontWeight: 400 }}>
            · Code: <span style={{ color: 'var(--gold)' }}>{d.user?.referral_code}</span>
          </span>
        </h2>
      </div>

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 2, padding: '0.75rem 2rem 0', borderBottom: '0.5px solid var(--border)', overflowX: 'auto' }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            background: tab === t ? 'var(--gold-dim)' : 'transparent',
            color: tab === t ? 'var(--gold)' : 'var(--muted)',
            border: tab === t ? '0.5px solid var(--gold-border)' : '0.5px solid transparent',
            borderBottom: 'none', borderRadius: '6px 6px 0 0',
            padding: '7px 14px', fontSize: 12, cursor: 'pointer',
            fontFamily: 'DM Sans, sans-serif', whiteSpace: 'nowrap', letterSpacing: '0.3px'
          }}>{t}</button>
        ))}
      </div>

      <div className="section">
        {tab === 'Overview' && (
          <OverviewTab
            stats={stats} teamStats={teamStats}
            qualifiedLevels={d.qualifiedLevels || []}
            referralLink={d.referralLink}
            recentSales={d.recentSales || []}
            pendingPayout={d.pendingPayout || 0}
            totalPaid={d.totalPaid || 0}
            networkCommissionsThisMonth={d.networkCommissionsThisMonth || 0}
            uplineChain={d.uplineChain || []}
            copied={copied} onCopy={copyRef}
            userCode={d.user?.referral_code}
          />
        )}
        {tab === 'My Team' && <TeamTab team={team} teamStats={teamStats} qualifiedLevels={d.qualifiedLevels || []} />}
        {tab === 'Sales' && <SalesTab sales={sales} />}
        {tab === 'Commissions' && <CommissionsTab comms={comms} />}
        {tab === 'Earnings' && <EarningsTab earnings={earnings} stats={stats} pendingPayout={d.pendingPayout || 0} totalPaid={d.totalPaid || 0} />}
        {tab === 'Record Sale' && (
          <RecordSaleTab onSold={() => {
            setSales(null); setEarnings(null);
            loadDashboard();
          }} />
        )}
      </div>
    </div>
  );
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────
function OverviewTab({ stats, teamStats, qualifiedLevels, referralLink, recentSales,
  pendingPayout, totalPaid, networkCommissionsThisMonth, uplineChain, copied, onCopy, userCode }) {

  const nextP = teamStats.nextProgress;

  return (
    <div>
      {/* KPI grid */}
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Books Sold', value: stats.count || 0, sub: 'all time' },
          { label: 'This Month', value: stats.month_count || 0, sub: 'books sold' },
          { label: 'Direct Earnings', value: `GH₵ ${Number(stats.total_commission || 0).toFixed(2)}`, sub: 'from your sales' },
          { label: 'Network Earnings', value: `GH₵ ${Number(networkCommissionsThisMonth).toFixed(2)}`, sub: 'from team this month' },
        ].map(s => (
          <div key={s.label} className="card" style={{ position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, right: 0, width: 60, height: 60, background: 'radial-gradient(circle at top right, rgba(201,168,76,0.08), transparent)', borderRadius: '0 12px 0 60px' }} />
            <div className="stat-label-sm" style={{ marginBottom: 8 }}>{s.label}</div>
            <div className="stat-num">{s.value}</div>
            <div className="stat-label-sm" style={{ marginTop: 3 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '1.25rem', marginBottom: '1.5rem' }}>
        {/* Level Progress */}
        <div className="card">
          <div className="label" style={{ marginBottom: 14 }}>Level Progress</div>
          {LEVELS.map(l => {
            const have = teamStats.byLevel?.[l.level] || 0;
            const pct = Math.min(100, (have / l.required) * 100);
            const done = qualifiedLevels.includes(l.level);
            return (
              <div key={l.level} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 12, color: done ? 'var(--gold)' : 'var(--muted)', display: 'flex', alignItems: 'center', gap: 5 }}>
                    Level {l.level}
                    {done && <span style={{ fontSize: 9, background: 'var(--gold-dim)', color: 'var(--gold)', padding: '1px 6px', borderRadius: 10 }}>UNLOCKED</span>}
                  </span>
                  <span style={{ fontSize: 11, color: 'var(--muted)' }}>{Math.min(have, l.required).toLocaleString()} / {l.required.toLocaleString()}</span>
                </div>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: pct + '%', opacity: done ? 1 : 0.55 }} />
                </div>
              </div>
            );
          })}
          {nextP && (
            <div style={{ marginTop: 8, padding: '8px 10px', background: 'var(--gold-dim)', borderRadius: 'var(--radius)', fontSize: 12, color: 'var(--gold)' }}>
              ✦ Need {(nextP.need - nextP.have).toLocaleString()} more members to unlock Level {nextP.level}
            </div>
          )}
          <div style={{ marginTop: 10, fontSize: 12, color: 'var(--muted)' }}>
            Total team: <strong style={{ color: 'var(--white)' }}>{teamStats.total}</strong> members
          </div>
        </div>

        {/* Referral + payout */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="card" style={{ flex: 1 }}>
            <div className="label" style={{ marginBottom: 10 }}>Your Referral Link</div>
            <div style={{
              background: 'var(--surface2)', border: '0.5px solid var(--border)',
              borderRadius: 'var(--radius)', padding: '9px 12px', marginBottom: 8,
              fontSize: 11, color: 'var(--muted)', wordBreak: 'break-all', lineHeight: 1.5
            }}>{referralLink || `kamaleads.com?ref=${userCode}`}</div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-outline btn-sm" style={{ flex: 1 }} onClick={onCopy}>
                {copied ? '✓ Copied!' : 'Copy Link'}
              </button>
              <a href={`https://wa.me/?text=📖 Get this powerful book by Prophet Mark Kama! ${referralLink}`}
                target="_blank" rel="noopener" className="btn btn-ghost btn-sm" style={{ flex: 1 }}>
                WhatsApp ↗
              </a>
            </div>
          </div>

          <div className="card">
            <div className="label" style={{ marginBottom: 10 }}>Payout Summary</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: 'var(--muted)' }}>Pending</span>
                <span style={{ fontSize: 14, color: 'var(--gold)', fontWeight: 500 }}>GH₵ {Number(pendingPayout).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: 'var(--muted)' }}>Paid out</span>
                <span style={{ fontSize: 14, color: '#4caf7d' }}>GH₵ {Number(totalPaid).toFixed(2)}</span>
              </div>
              <div className="divider" style={{ margin: '4px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: 'var(--muted)' }}>Total earned</span>
                <span style={{ fontSize: 15, color: 'var(--white)', fontWeight: 500 }}>
                  GH₵ {(Number(pendingPayout) + Number(totalPaid) + Number(stats.total_commission || 0)).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Upline */}
      {uplineChain.length > 0 && (
        <div className="card" style={{ marginBottom: '1.25rem', padding: '1rem 1.25rem' }}>
          <div className="label" style={{ marginBottom: 8 }}>Your Upline Chain</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            {uplineChain.map((u, i) => (
              <div key={u.id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 12, color: 'var(--muted)' }}>L{i + 1}</span>
                <span style={{ background: 'var(--surface2)', border: '0.5px solid var(--border)', padding: '3px 10px', borderRadius: 20, fontSize: 12 }}>{u.name}</span>
                {i < uplineChain.length - 1 && <span style={{ color: 'var(--gold)', fontSize: 10 }}>→</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Sales */}
      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '0.5px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="label">Recent Sales</div>
          <span style={{ fontSize: 12, color: 'var(--muted)' }}>{recentSales.length} records</span>
        </div>
        {recentSales.length === 0
          ? <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)', fontSize: 13 }}>
              No sales yet — share your referral link to get started.
            </div>
          : <table>
              <thead><tr><th>Book</th><th>Buyer</th><th>Amount</th><th>Commission</th><th>Date</th></tr></thead>
              <tbody>{recentSales.map(s => (
                <tr key={s.id}>
                  <td style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span>{s.cover_emoji}</span> {s.title}
                  </td>
                  <td style={{ color: 'var(--muted)' }}>{s.buyer_name || s.buyer_email || '—'}</td>
                  <td className="gold">GH₵ {s.amount_ghc}</td>
                  <td style={{ color: '#4caf7d' }}>+ GH₵ {s.commission_ghc}</td>
                  <td style={{ color: 'var(--muted)' }}>{s.created_at?.slice(0, 10)}</td>
                </tr>
              ))}</tbody>
            </table>
        }
      </div>
    </div>
  );
}

// ─── Team Tab ─────────────────────────────────────────────────────────────────
function TeamTab({ team, teamStats, qualifiedLevels }) {
  const [viewLevel, setViewLevel] = useState('all');

  if (!team) return <div style={{ color: 'var(--muted)', padding: '2rem' }}>Loading team…</div>;

  const downline = team.downline || [];
  const byLevel = {};
  for (const m of downline) {
    byLevel[m.depth] = byLevel[m.depth] || [];
    byLevel[m.depth].push(m);
  }

  const shown = viewLevel === 'all' ? downline : (byLevel[parseInt(viewLevel)] || []);

  return (
    <div>
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {LEVELS.map(l => {
          const count = teamStats?.byLevel?.[l.level] || 0;
          const done = qualifiedLevels.includes(l.level);
          return (
            <div key={l.level} className="card" style={{ borderColor: done ? 'rgba(201,168,76,0.5)' : 'var(--border)', cursor: 'pointer' }}
              onClick={() => setViewLevel(String(l.level))}>
              <div className="label" style={{ marginBottom: 4 }}>Level {l.level}</div>
              <div className="stat-num" style={{ fontSize: '1.8rem' }}>{count.toLocaleString()}</div>
              <div className="stat-label-sm">of {l.required.toLocaleString()} needed</div>
              <div style={{ marginTop: 8 }}>
                <span className={`badge ${done ? 'badge-green' : 'badge-muted'}`}>
                  {done ? '✦ Qualified' : 'In progress'}
                </span>
              </div>
              {done && (
                <div style={{ marginTop: 6, fontSize: 11, color: 'var(--gold)' }}>
                  Earn GH₵ {(3.5 * count).toLocaleString()} per book cycle
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Filter */}
      <div style={{ display: 'flex', gap: 6, marginBottom: '1rem', flexWrap: 'wrap' }}>
        <button className={`btn btn-sm ${viewLevel === 'all' ? 'btn-gold' : 'btn-ghost'}`} onClick={() => setViewLevel('all')}>
          All ({downline.length})
        </button>
        {Object.entries(byLevel).map(([lvl, members]) => (
          <button key={lvl} className={`btn btn-sm ${viewLevel === lvl ? 'btn-gold' : 'btn-ghost'}`} onClick={() => setViewLevel(lvl)}>
            Level {lvl} ({members.length})
          </button>
        ))}
      </div>

      {shown.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--muted)' }}>
            No team members yet. Share your referral link!
          </div>
        : <div className="card" style={{ padding: 0 }}>
            <table>
              <thead><tr><th>Name</th><th>Email</th><th>Level</th><th>Code</th><th>Sales</th><th>Joined</th></tr></thead>
              <tbody>{shown.map(m => (
                <tr key={m.id}>
                  <td>{m.name}</td>
                  <td style={{ color: 'var(--muted)' }}>{m.email}</td>
                  <td><span className="badge badge-gold">L{m.depth}</span></td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--gold)' }}>{m.referral_code}</td>
                  <td>{m.sales_count || 0}</td>
                  <td style={{ color: 'var(--muted)' }}>{m.created_at?.slice(0, 10)}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
      }
    </div>
  );
}

// ─── Sales Tab ────────────────────────────────────────────────────────────────
function SalesTab({ sales }) {
  const [search, setSearch] = useState('');
  if (!sales) return <div style={{ color: 'var(--muted)', padding: '1rem' }}>Loading…</div>;
  const filtered = search
    ? sales.filter(s => (s.buyer_name + s.buyer_email + s.title).toLowerCase().includes(search.toLowerCase()))
    : sales;

  const totalRevenue = sales.reduce((a, s) => a + s.amount_ghc, 0);
  const totalCommission = sales.reduce((a, s) => a + s.commission_ghc, 0);

  return (
    <div>
      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        <div className="card" style={{ flex: 1, minWidth: 140 }}>
          <div className="stat-label-sm">Total sales</div>
          <div className="stat-num" style={{ fontSize: '1.6rem' }}>{sales.length}</div>
        </div>
        <div className="card" style={{ flex: 1, minWidth: 140 }}>
          <div className="stat-label-sm">Revenue generated</div>
          <div className="stat-num" style={{ fontSize: '1.6rem' }}>GH₵ {totalRevenue.toFixed(0)}</div>
        </div>
        <div className="card" style={{ flex: 1, minWidth: 140 }}>
          <div className="stat-label-sm">Your commissions</div>
          <div className="stat-num" style={{ fontSize: '1.6rem', color: '#4caf7d' }}>GH₵ {totalCommission.toFixed(2)}</div>
        </div>
      </div>

      <div style={{ marginBottom: '1rem', maxWidth: 340 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by buyer or book…" />
      </div>

      <div className="card" style={{ padding: 0 }}>
        {filtered.length === 0
          ? <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)' }}>No sales found.</div>
          : <table>
              <thead><tr><th>Book</th><th>Buyer</th><th>Amount</th><th>Commission</th><th>Ref</th><th>Date</th></tr></thead>
              <tbody>{filtered.map(s => (
                <tr key={s.id}>
                  <td>{s.cover_emoji} {s.title}</td>
                  <td style={{ color: 'var(--muted)' }}>{s.buyer_name || s.buyer_email || '—'}</td>
                  <td className="gold">GH₵ {s.amount_ghc}</td>
                  <td style={{ color: '#4caf7d' }}>+ GH₵ {s.commission_ghc}</td>
                  <td style={{ fontSize: 11, color: 'var(--muted)' }}>{s.payment_ref || '—'}</td>
                  <td style={{ color: 'var(--muted)' }}>{s.created_at?.slice(0, 10)}</td>
                </tr>
              ))}</tbody>
            </table>
        }
      </div>
    </div>
  );
}

// ─── Commissions Tab ──────────────────────────────────────────────────────────
function CommissionsTab({ comms }) {
  if (!comms) return <div style={{ color: 'var(--muted)', padding: '1rem' }}>Loading…</div>;

  const pending = comms.filter(c => c.status === 'pending');
  const paid = comms.filter(c => c.status === 'paid');
  const pendingTotal = pending.reduce((a, c) => a + c.amount_ghc, 0);
  const paidTotal = paid.reduce((a, c) => a + c.amount_ghc, 0);

  return (
    <div>
      <div className="grid-3" style={{ marginBottom: '1.5rem' }}>
        <div className="card">
          <div className="stat-label-sm">Pending commissions</div>
          <div className="stat-num" style={{ fontSize: '1.5rem' }}>GH₵ {pendingTotal.toFixed(2)}</div>
          <div className="stat-label-sm">{pending.length} transactions</div>
        </div>
        <div className="card">
          <div className="stat-label-sm">Paid out</div>
          <div className="stat-num" style={{ fontSize: '1.5rem', color: '#4caf7d' }}>GH₵ {paidTotal.toFixed(2)}</div>
          <div className="stat-label-sm">{paid.length} transactions</div>
        </div>
        <div className="card">
          <div className="stat-label-sm">Total network earnings</div>
          <div className="stat-num" style={{ fontSize: '1.5rem' }}>GH₵ {(pendingTotal + paidTotal).toFixed(2)}</div>
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {comms.length === 0
          ? <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)' }}>
              No network commissions yet. Qualify a level by building your team.
            </div>
          : <table>
              <thead><tr><th>Book</th><th>Sold by</th><th>Level</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
              <tbody>{comms.map(c => (
                <tr key={c.id}>
                  <td>{c.cover_emoji} {c.book_title}</td>
                  <td style={{ color: 'var(--muted)' }}>{c.buyer_seller_name || '—'}</td>
                  <td><span className="badge badge-gold">L{c.level}</span></td>
                  <td className="gold">GH₵ {c.amount_ghc}</td>
                  <td><span className={`badge ${c.status === 'paid' ? 'badge-green' : 'badge-muted'}`}>{c.status}</span></td>
                  <td style={{ color: 'var(--muted)' }}>{c.created_at?.slice(0, 10)}</td>
                </tr>
              ))}</tbody>
            </table>
        }
      </div>
    </div>
  );
}

// ─── Earnings Tab ─────────────────────────────────────────────────────────────
function EarningsTab({ earnings, stats, pendingPayout, totalPaid }) {
  if (!earnings) return <div style={{ color: 'var(--muted)', padding: '1rem' }}>Loading…</div>;

  const directTotal = Number(earnings.total_direct || 0);
  const networkTotal = Number(earnings.total_network || 0);
  const grandTotal = directTotal + networkTotal;

  return (
    <div>
      <div className="grid-3" style={{ marginBottom: '1.5rem' }}>
        <div className="card">
          <div className="stat-label-sm">Direct sales commissions</div>
          <div className="stat-num">GH₵ {directTotal.toFixed(2)}</div>
          <div className="stat-label-sm">5% on your own sales</div>
        </div>
        <div className="card">
          <div className="stat-label-sm">Network commissions</div>
          <div className="stat-num">GH₵ {networkTotal.toFixed(2)}</div>
          <div className="stat-label-sm">from your team's sales</div>
        </div>
        <div className="card" style={{ borderColor: 'rgba(201,168,76,0.4)' }}>
          <div className="stat-label-sm">Grand total earned</div>
          <div className="stat-num">GH₵ {grandTotal.toFixed(2)}</div>
          <div className="stat-label-sm">GH₵ {Number(pendingPayout).toFixed(2)} pending payout</div>
        </div>
      </div>

      <div className="label" style={{ marginBottom: 12 }}>Monthly Breakdown</div>
      <div className="card" style={{ padding: 0 }}>
        {(!earnings.monthly || earnings.monthly.length === 0)
          ? <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)' }}>No monthly data yet.</div>
          : <table>
              <thead><tr><th>Month</th><th>Books Sold</th><th>Direct Commission</th><th>Network Commission</th><th>Total</th></tr></thead>
              <tbody>{earnings.monthly.map(m => (
                <tr key={m.month}>
                  <td>{m.month}</td>
                  <td>{m.sales}</td>
                  <td className="gold">GH₵ {Number(m.direct_commission).toFixed(2)}</td>
                  <td style={{ color: '#4caf7d' }}>GH₵ {Number(m.network_commission).toFixed(2)}</td>
                  <td style={{ fontWeight: 500 }}>GH₵ {(Number(m.direct_commission) + Number(m.network_commission)).toFixed(2)}</td>
                </tr>
              ))}</tbody>
            </table>
        }
      </div>
    </div>
  );
}

// ─── Record Sale Tab ──────────────────────────────────────────────────────────
function RecordSaleTab({ onSold }) {
  const [books, setBooks] = useState([]);
  const [form, setForm] = useState({ bookId: '', buyerName: '', buyerEmail: '', paymentRef: '' });
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.getBooks().then(b => {
      setBooks(b);
      if (b[0]) setForm(f => ({ ...f, bookId: b[0].id }));
    });
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setResult(null); setLoading(true);
    try {
      const r = await api.recordSale(form);
      setResult(r);
      onSold();
      setForm(f => ({ ...f, buyerName: '', buyerEmail: '', paymentRef: '' }));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const selectedBook = books.find(b => b.id === form.bookId);

  return (
    <div style={{ maxWidth: 500 }}>
      <div className="label" style={{ marginBottom: 16 }}>Record a Book Sale</div>

      {result && (
        <div className="success-msg">
          ✦ Sale recorded! You earned <strong>GH₵ {result.commission_ghc}</strong>
          {result.upline_commissions_awarded > 0 && ` · ${result.upline_commissions_awarded} upline commission(s) awarded`}
        </div>
      )}
      {error && <div className="error-msg">{error}</div>}

      <div className="card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Book sold</label>
            <select value={form.bookId} onChange={e => setForm(f => ({ ...f, bookId: e.target.value }))}>
              {books.map(b => (
                <option key={b.id} value={b.id}>{b.cover_emoji} {b.title}: {b.subtitle} — GH₵{b.price_ghc}</option>
              ))}
            </select>
          </div>

          {selectedBook && (
            <div style={{ background: 'var(--gold-dim)', border: '0.5px solid var(--gold-border)', borderRadius: 'var(--radius)', padding: '10px 14px', marginBottom: '1rem', display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: 'var(--muted)' }}>Your commission</span>
              <span style={{ fontSize: 15, color: 'var(--gold)', fontWeight: 500 }}>
                GH₵ {(selectedBook.price_ghc * selectedBook.commission_pct / 100).toFixed(2)}
              </span>
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Buyer name <span style={{ color: 'var(--muted)' }}>(optional)</span></label>
            <input value={form.buyerName} onChange={e => setForm(f => ({ ...f, buyerName: e.target.value }))} placeholder="Customer full name" />
          </div>
          <div className="form-group">
            <label className="form-label">Buyer email <span style={{ color: 'var(--muted)' }}>(optional)</span></label>
            <input type="email" value={form.buyerEmail} onChange={e => setForm(f => ({ ...f, buyerEmail: e.target.value }))} placeholder="customer@email.com" />
          </div>
          <div className="form-group">
            <label className="form-label">Payment reference <span style={{ color: 'var(--muted)' }}>(optional)</span></label>
            <input value={form.paymentRef} onChange={e => setForm(f => ({ ...f, paymentRef: e.target.value }))} placeholder="MTN MoMo ref / Paystack ref" />
          </div>
          <button type="submit" className="btn btn-gold btn-full" disabled={loading || !form.bookId}>
            {loading ? 'Recording…' : `Record Sale & Earn GH₵ ${selectedBook ? (selectedBook.price_ghc * selectedBook.commission_pct / 100).toFixed(2) : '3.50'}`}
          </button>
        </form>
      </div>

      <div className="card-dark" style={{ marginTop: '1rem', padding: '1rem' }}>
        <div className="label" style={{ marginBottom: 8, fontSize: 9 }}>Commission Rules</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {[
            'You earn 5% (GH₵ 3.50) on every book you sell directly',
            'Qualified upline members also earn 5% on your sales',
            'To qualify a level, build the required team at that depth',
            'Commissions are paid out by admin via mobile money',
          ].map((r, i) => (
            <div key={i} style={{ fontSize: 12, color: 'var(--muted)', display: 'flex', gap: 8 }}>
              <span style={{ color: 'var(--gold)' }}>✦</span> {r}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
