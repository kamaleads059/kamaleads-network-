import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, saveAuth } from '../lib/api.js';
import { useAuth } from '../App.jsx';

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const { token, user } = await api.login(form);
      saveAuth(token, user);
      login(user);
      navigate(user.role === 'admin' ? '/admin' : '/seller');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ minHeight: 'calc(100vh - 60px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 36, color: 'var(--gold)', marginBottom: 4 }}>Welcome Back</div>
          <div style={{ color: 'var(--muted)', fontSize: 14 }}>Sign in to your Kamaleads account</div>
        </div>

        <div className="card">
          {error && <div className="error-msg">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="you@example.com" required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="••••••••" required />
            </div>
            <button type="submit" className="btn btn-gold btn-full" disabled={loading} style={{ marginTop: 8 }}>
              {loading ? 'Signing in…' : 'Sign In →'}
            </button>
          </form>

          <div className="divider" />
          <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--muted)' }}>
            No account? <Link to="/register">Join as a seller</Link>
          </div>
        </div>

        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: 'var(--faint)', fontStyle: 'italic' }}>
            Admin: admin@kamaleads.com / admin1234
          </div>
        </div>
      </div>
    </div>
  );
}
