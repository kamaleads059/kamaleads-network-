import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useState, useEffect, createContext, useContext } from 'react';
import { getUser, logout as doLogout } from './lib/api.js';
import './index.css';

import StorePage from './pages/StorePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';
import SellerDashboard from './pages/SellerDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import Navbar from './components/Navbar.jsx';

export const AuthContext = createContext(null);
export function useAuth() { return useContext(AuthContext); }

function PrivateRoute({ children, adminOnly = false }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/seller" replace />;
  return children;
}

export default function App() {
  const [user, setUser] = useState(() => getUser());

  function login(u) { setUser(u); }
  function logout() { doLogout(); setUser(null); }

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<StorePage />} />
          <Route path="/login" element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/seller'} /> : <LoginPage />} />
          <Route path="/register" element={user ? <Navigate to="/seller" /> : <RegisterPage />} />
          <Route path="/seller" element={<PrivateRoute><SellerDashboard /></PrivateRoute>} />
          <Route path="/admin" element={<PrivateRoute adminOnly><AdminDashboard /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </AuthContext.Provider>
  );
}
