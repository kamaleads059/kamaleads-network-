import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../App.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <header style={{
      background: '#0A0A0A',
      borderBottom: '1px solid rgba(201,168,76,0.25)',
      padding: '0 2rem',
      height: 60,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 100,
    }}>
      <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
        <div style={{
          width: 34, height: 34, background: 'var(--gold)', color: '#000',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Cormorant Garamond, serif', fontSize: 20, fontWeight: 600,
          borderRadius: 4,
        }}>K</div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--white)', letterSpacing: 1 }}>
            KAMA<span style={{ color: 'var(--gold)' }}>LEADS</span>
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 1.5 }}>NETWORK</div>
        </div>
      </Link>

      <nav style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <NavLink to="/" label="Store" pathname={pathname} />
        {user && user.role !== 'admin' && <NavLink to="/seller" label="My Account" pathname={pathname} />}
        {user && user.role === 'admin' && <NavLink to="/admin" label="Admin" pathname={pathname} />}

        {!user ? (
          <>
            <Link to="/login" className="btn btn-ghost btn-sm" style={{ marginLeft: 4 }}>Log in</Link>
            <Link to="/register" className="btn btn-gold btn-sm">Join as Seller</Link>
          </>
        ) : (
          <button onClick={handleLogout} className="btn btn-ghost btn-sm" style={{ marginLeft: 4 }}>
            Log out
          </button>
        )}
      </nav>
    </header>
  );
}

function NavLink({ to, label, pathname }) {
  const active = pathname === to;
  return (
    <Link to={to} style={{
      padding: '6px 12px',
      borderRadius: 'var(--radius)',
      fontSize: 13,
      color: active ? 'var(--gold)' : 'var(--muted)',
      background: active ? 'var(--gold-dim)' : 'transparent',
      transition: 'all 0.15s',
      textDecoration: 'none',
    }}>{label}</Link>
  );
}
