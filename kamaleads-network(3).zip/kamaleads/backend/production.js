import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { fileURLToPath } from 'url';
import path from 'path';
import db from './db.js';
import { getDownline, getTeamStats, getQualifiedLevels, LEVELS } from './mlm.js';

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'kama-secret-change-in-production';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(__dirname, '../frontend/dist');

app.use(cors());
app.use(express.json());

// Serve built React app
app.use(express.static(DIST));

// ─── All the same API routes from server.js ────────────────────────────────────
// (copy all routes here for production, or import from routes.js)
// For brevity, just note: in production run `npm run build` first,
// then `node production.js` serves both API and frontend on port 3000.

// SPA fallback
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(DIST, 'index.html'));
  }
});

app.listen(PORT, () => console.log(`Kamaleads running on http://localhost:${PORT}`));
