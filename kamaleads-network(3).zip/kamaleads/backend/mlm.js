import db from './db.js';
import { v4 as uuidv4 } from 'uuid';

export const LEVELS = [
  { level: 1, required: 5 },
  { level: 2, required: 25 },
  { level: 3, required: 125 },
  { level: 4, required: 625 },
  { level: 5, required: 3125 },
];

// Get full downline up to 5 levels deep
export function getDownline(userId, maxDepth = 5) {
  const results = [];
  const visited = new Set();

  function recurse(parentId, currentDepth) {
    if (currentDepth > maxDepth) return;
    const children = db.prepare(
      'SELECT id, name, email, phone, referral_code, referred_by, created_at FROM users WHERE referred_by = ?'
    ).all(parentId);
    for (const child of children) {
      if (visited.has(child.id)) continue;
      visited.add(child.id);
      results.push({ ...child, depth: currentDepth, parentId });
      recurse(child.id, currentDepth + 1);
    }
  }

  recurse(userId, 1);
  return results;
}

// Count team members by level depth
export function getTeamStats(userId) {
  const downline = getDownline(userId, 5);
  const byLevel = {};
  for (const m of downline) {
    byLevel[m.depth] = (byLevel[m.depth] || 0) + 1;
  }
  const qualifiedLevels = LEVELS
    .filter(l => (byLevel[l.level] || 0) >= l.required)
    .map(l => l.level);

  // Next level to unlock
  const nextLevel = LEVELS.find(l => !qualifiedLevels.includes(l.level));
  const nextProgress = nextLevel
    ? { level: nextLevel.level, have: byLevel[nextLevel.level] || 0, need: nextLevel.required }
    : null;

  return { total: downline.length, byLevel, qualifiedLevels, nextProgress };
}

export function getQualifiedLevels(userId) {
  return getTeamStats(userId).qualifiedLevels;
}

// Walk up the referral chain and award commissions to qualified upline members
export function processSaleCommissions(saleId) {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(saleId);
  if (!sale) return [];

  const insertComm = db.prepare(`
    INSERT INTO commissions (id, seller_id, sale_id, level, amount_ghc, status)
    VALUES (?, ?, ?, ?, ?, 'pending')
  `);

  const awarded = [];
  let currentId = sale.seller_id;
  let depth = 0;
  const visited = new Set([currentId]);

  while (depth < 5) {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(currentId);
    if (!user?.referred_by) break;
    depth++;

    const upline = db.prepare('SELECT * FROM users WHERE id = ?').get(user.referred_by);
    if (!upline || visited.has(upline.id)) break;
    visited.add(upline.id);

    const qualified = getQualifiedLevels(upline.id);
    if (qualified.includes(depth)) {
      const commId = 'comm-' + uuidv4().slice(0, 8);
      insertComm.run(commId, upline.id, saleId, depth, sale.commission_ghc);
      awarded.push({ sellerId: upline.id, level: depth, amount: sale.commission_ghc });
    }

    currentId = upline.id;
  }

  return awarded;
}

// Get a seller's upline chain (who recruited them, who recruited that person, etc.)
export function getUplineChain(userId) {
  const chain = [];
  let current = db.prepare('SELECT id, name, email, referral_code, referred_by FROM users WHERE id = ?').get(userId);
  const visited = new Set();

  while (current?.referred_by && !visited.has(current.id)) {
    visited.add(current.id);
    const parent = db.prepare('SELECT id, name, email, referral_code, referred_by FROM users WHERE id = ?').get(current.referred_by);
    if (!parent) break;
    chain.push(parent);
    current = parent;
  }

  return chain;
}

// Monthly earnings summary for a seller
export function getMonthlyEarnings(userId) {
  return db.prepare(`
    SELECT
      strftime('%Y-%m', s.created_at) as month,
      COUNT(s.id) as sales,
      COALESCE(SUM(s.commission_ghc), 0) as direct_commission,
      COALESCE(
        (SELECT SUM(c.amount_ghc) FROM commissions c
         WHERE c.seller_id = ? AND strftime('%Y-%m', c.created_at) = strftime('%Y-%m', s.created_at)
         AND c.status != 'cancelled'),
        0
      ) as network_commission
    FROM sales s
    WHERE s.seller_id = ?
    GROUP BY month
    ORDER BY month DESC
    LIMIT 12
  `).all(userId, userId);
}

// Network-wide stats per level for admin
export function getNetworkLevelStats() {
  // For each level, find all sellers who qualify at that level
  const allSellers = db.prepare("SELECT id FROM users WHERE role = 'seller'").all();
  const stats = LEVELS.map(l => ({ level: l.level, required: l.required, qualified: 0, total_sellers: allSellers.length }));

  for (const seller of allSellers) {
    const qualified = getQualifiedLevels(seller.id);
    for (const lvl of qualified) {
      const s = stats.find(s => s.level === lvl);
      if (s) s.qualified++;
    }
  }

  return stats;
}
