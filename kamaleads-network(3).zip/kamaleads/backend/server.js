import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { fileURLToPath } from 'url';
import path from 'path';
import db from './db.js';
import {
  getDownline, getTeamStats, getQualifiedLevels,
  processSaleCommissions, getUplineChain,
  getMonthlyEarnings, getNetworkLevelStats, LEVELS
} from './mlm.js';

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'kama-secret-key-change-in-production';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors({ origin: '*' }));
app.use(express.json());

// ── Serve built React frontend ──────────────────────────────────────────────
const DIST = path.join(__dirname, '../frontend/dist');
app.use(express.static(DIST));

// ─── Auth Middleware ─────────────────────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid token' }); }
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ─── Auth ────────────────────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, phone, password, referralCode } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ error: 'Email already registered' });
    let referredBy = null;
    if (referralCode) {
      const referrer = db.prepare('SELECT id FROM users WHERE referral_code = ?').get(referralCode.toUpperCase().trim());
      if (referrer) referredBy = referrer.id;
    }
    const hash = await bcrypt.hash(password, 10);
    const id = 'user-' + uuidv4().slice(0, 8);
    const myCode = 'KL' + Math.random().toString(36).toUpperCase().slice(2, 8);
    db.prepare(`INSERT INTO users (id,name,email,phone,password_hash,referral_code,referred_by) VALUES (?,?,?,?,?,?,?)`)
      .run(id, name.trim(), email.toLowerCase().trim(), phone?.trim()||null, hash, myCode, referredBy);
    const user = db.prepare('SELECT id,name,email,phone,role,referral_code,created_at FROM users WHERE id=?').get(id);
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Registration failed' }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    const { password_hash, ...safe } = user;
    res.json({ token, user: safe });
  } catch (err) { res.status(500).json({ error: 'Login failed' }); }
});

app.get('/api/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,name,email,phone,role,referral_code,created_at FROM users WHERE id=?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  res.json(user);
});

// ─── Books ───────────────────────────────────────────────────────────────────
app.get('/api/books', (_, res) => res.json(db.prepare('SELECT * FROM books WHERE active=1').all()));

app.post('/api/books', auth, adminOnly, (req, res) => {
  const { title, subtitle, author, price_ghc, description, cover_emoji } = req.body;
  if (!title || !price_ghc) return res.status(400).json({ error: 'Title and price required' });
  const id = 'book-' + uuidv4().slice(0, 8);
  db.prepare(`INSERT INTO books (id,title,subtitle,author,price_ghc,commission_pct,description,cover_emoji) VALUES (?,?,?,?,?,5,?,?)`)
    .run(id, title, subtitle||null, author||'Prophet Mark Kama', price_ghc, description||null, cover_emoji||'📚');
  res.json({ id, message: 'Book added' });
});

app.patch('/api/books/:id', auth, adminOnly, (req, res) => {
  const { title, subtitle, price_ghc, description, active } = req.body;
  db.prepare(`UPDATE books SET title=COALESCE(?,title),subtitle=COALESCE(?,subtitle),price_ghc=COALESCE(?,price_ghc),description=COALESCE(?,description),active=COALESCE(?,active) WHERE id=?`)
    .run(title||null, subtitle||null, price_ghc||null, description||null, active??null, req.params.id);
  res.json({ ok: true });
});

// ─── Sales ───────────────────────────────────────────────────────────────────
app.post('/api/sales', auth, (req, res) => {
  try {
    const { bookId, buyerEmail, buyerName, paymentRef } = req.body;
    if (!bookId) return res.status(400).json({ error: 'bookId required' });
    const book = db.prepare('SELECT * FROM books WHERE id=? AND active=1').get(bookId);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    const commission = +(book.price_ghc * book.commission_pct / 100).toFixed(2);
    const id = 'sale-' + uuidv4().slice(0, 8);
    db.prepare(`INSERT INTO sales (id,seller_id,book_id,buyer_email,buyer_name,amount_ghc,commission_ghc,payment_ref) VALUES (?,?,?,?,?,?,?,?)`)
      .run(id, req.user.id, bookId, buyerEmail?.trim()||null, buyerName?.trim()||null, book.price_ghc, commission, paymentRef?.trim()||null);
    const awarded = processSaleCommissions(id);
    res.json({ id, commission_ghc: commission, upline_commissions_awarded: awarded.length });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed to record sale' }); }
});

app.get('/api/sales/my', auth, (req, res) => {
  res.json(db.prepare(`SELECT s.*,b.title,b.subtitle,b.cover_emoji FROM sales s JOIN books b ON b.id=s.book_id WHERE s.seller_id=? ORDER BY s.created_at DESC LIMIT 100`).all(req.user.id));
});

// ─── Seller ──────────────────────────────────────────────────────────────────
app.get('/api/seller/dashboard', auth, (req, res) => {
  try {
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    const { password_hash, ...safeUser } = user;
    const allTime = db.prepare(`SELECT COUNT(*) as count,COALESCE(SUM(amount_ghc),0) as total_sales,COALESCE(SUM(commission_ghc),0) as total_commission FROM sales WHERE seller_id=?`).get(req.user.id);
    const month = db.prepare(`SELECT COALESCE(SUM(amount_ghc),0) as month_sales,COALESCE(SUM(commission_ghc),0) as month_commission,COUNT(*) as month_count FROM sales WHERE seller_id=? AND created_at>=date('now','start of month')`).get(req.user.id);
    const teamStats = getTeamStats(req.user.id);
    const pendingPayout = db.prepare(`SELECT COALESCE(SUM(amount_ghc),0) as total FROM commissions WHERE seller_id=? AND status='pending'`).get(req.user.id);
    const totalPaid = db.prepare(`SELECT COALESCE(SUM(amount_ghc),0) as total FROM commissions WHERE seller_id=? AND status='paid'`).get(req.user.id);
    const netCommMonth = db.prepare(`SELECT COALESCE(SUM(amount_ghc),0) as total FROM commissions WHERE seller_id=? AND created_at>=date('now','start of month')`).get(req.user.id);
    const recentSales = db.prepare(`SELECT s.*,b.title,b.cover_emoji FROM sales s JOIN books b ON b.id=s.book_id WHERE s.seller_id=? ORDER BY s.created_at DESC LIMIT 10`).all(req.user.id);
    const host = req.headers.origin || `https://${req.headers.host}` || 'https://kamaleads.com';
    res.json({
      user: safeUser, stats: { ...allTime, ...month },
      teamStats, qualifiedLevels: teamStats.qualifiedLevels, levels: LEVELS,
      pendingPayout: pendingPayout.total, totalPaid: totalPaid.total,
      networkCommissionsThisMonth: netCommMonth.total,
      recentSales, uplineChain: getUplineChain(req.user.id),
      monthlyEarnings: getMonthlyEarnings(req.user.id),
      referralLink: `${host}?ref=${user.referral_code}`,
    });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Dashboard failed' }); }
});

app.get('/api/seller/team', auth, (req, res) => {
  const downline = getDownline(req.user.id, 5).map(m => {
    const s = db.prepare('SELECT COUNT(*) as c,COALESCE(SUM(amount_ghc),0) as rev FROM sales WHERE seller_id=?').get(m.id);
    return { ...m, sales_count: s.c, revenue: s.rev };
  });
  res.json({ downline, stats: getTeamStats(req.user.id) });
});

app.get('/api/seller/commissions', auth, (req, res) => {
  res.json(db.prepare(`SELECT c.*,s.amount_ghc as sale_amount,b.title as book_title,b.cover_emoji,u.name as buyer_seller_name FROM commissions c JOIN sales s ON s.id=c.sale_id JOIN books b ON b.id=s.book_id JOIN users u ON u.id=s.seller_id WHERE c.seller_id=? ORDER BY c.created_at DESC LIMIT 100`).all(req.user.id));
});

app.get('/api/seller/earnings-summary', auth, (req, res) => {
  const monthly = getMonthlyEarnings(req.user.id);
  const total_direct = db.prepare('SELECT COALESCE(SUM(commission_ghc),0) as t FROM sales WHERE seller_id=?').get(req.user.id).t;
  const total_network = db.prepare("SELECT COALESCE(SUM(amount_ghc),0) as t FROM commissions WHERE seller_id=? AND status!='cancelled'").get(req.user.id).t;
  res.json({ monthly, total_direct, total_network, grand_total: total_direct + total_network });
});

// ─── Admin ───────────────────────────────────────────────────────────────────
app.get('/api/admin/overview', auth, adminOnly, (req, res) => {
  try {
    const sellers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role='seller'").get().c;
    const totalSales = db.prepare('SELECT COUNT(*) as c,COALESCE(SUM(amount_ghc),0) as rev FROM sales').get();
    const pendingComms = db.prepare("SELECT COALESCE(SUM(amount_ghc),0) as c FROM commissions WHERE status='pending'").get().c;
    const paidComms = db.prepare("SELECT COALESCE(SUM(amount_ghc),0) as c FROM commissions WHERE status='paid'").get().c;
    const topSellers = db.prepare(`SELECT u.id,u.name,u.email,u.referral_code,u.created_at,COUNT(s.id) as sales_count,COALESCE(SUM(s.amount_ghc),0) as revenue FROM users u LEFT JOIN sales s ON s.seller_id=u.id WHERE u.role='seller' GROUP BY u.id ORDER BY revenue DESC LIMIT 10`).all();
    const recentSales = db.prepare(`SELECT s.*,u.name as seller_name,b.title as book_title,b.cover_emoji FROM sales s JOIN users u ON u.id=s.seller_id JOIN books b ON b.id=s.book_id ORDER BY s.created_at DESC LIMIT 20`).all();
    const newSellersThisWeek = db.prepare(`SELECT COUNT(*) as c FROM users WHERE role='seller' AND created_at>=date('now','-7 days')`).get().c;
    const salesThisMonth = db.prepare(`SELECT COUNT(*) as c,COALESCE(SUM(amount_ghc),0) as rev FROM sales WHERE created_at>=date('now','start of month')`).get();
    const monthlyRevenue = db.prepare(`SELECT strftime('%Y-%m',created_at) as month,COUNT(*) as sales,COALESCE(SUM(amount_ghc),0) as revenue FROM sales GROUP BY month ORDER BY month DESC LIMIT 12`).all();
    res.json({ sellers, totalSales, pendingComms, paidComms, newSellersThisWeek, salesThisMonth, topSellers, recentSales, networkLevelStats: getNetworkLevelStats(), monthlyRevenue });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Overview failed' }); }
});

app.get('/api/admin/sellers', auth, adminOnly, (req, res) => {
  const sellers = db.prepare(`SELECT u.id,u.name,u.email,u.phone,u.referral_code,u.referred_by,u.created_at,COUNT(s.id) as sales_count,COALESCE(SUM(s.amount_ghc),0) as revenue FROM users u LEFT JOIN sales s ON s.seller_id=u.id WHERE u.role='seller' GROUP BY u.id ORDER BY u.created_at DESC`).all();
  res.json(sellers.map(s => ({ ...s, team_size: getTeamStats(s.id).total, qualified_levels: getQualifiedLevels(s.id) })));
});

app.get('/api/admin/sellers/:id', auth, adminOnly, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  const { password_hash, ...safe } = user;
  res.json({ user: safe, teamStats: getTeamStats(user.id), sales: db.prepare(`SELECT s.*,b.title FROM sales s JOIN books b ON b.id=s.book_id WHERE s.seller_id=? ORDER BY s.created_at DESC LIMIT 20`).all(user.id), comms: db.prepare(`SELECT * FROM commissions WHERE seller_id=? ORDER BY created_at DESC LIMIT 20`).all(user.id) });
});

app.patch('/api/admin/sellers/:id', auth, adminOnly, (req, res) => {
  const { name, phone, role } = req.body;
  db.prepare('UPDATE users SET name=COALESCE(?,name),phone=COALESCE(?,phone),role=COALESCE(?,role) WHERE id=?').run(name||null, phone||null, role||null, req.params.id);
  res.json({ ok: true });
});

app.get('/api/admin/commissions', auth, adminOnly, (req, res) => {
  const { status, sellerId } = req.query;
  let q = `SELECT c.*,u.name as seller_name,u.email as seller_email,u.phone as seller_phone,b.title as book_title,b.cover_emoji,seller.name as sale_seller_name FROM commissions c JOIN users u ON u.id=c.seller_id JOIN sales s ON s.id=c.sale_id JOIN books b ON b.id=s.book_id JOIN users seller ON seller.id=s.seller_id WHERE 1=1`;
  const p = [];
  if (status) { q += ' AND c.status=?'; p.push(status); }
  if (sellerId) { q += ' AND c.seller_id=?'; p.push(sellerId); }
  q += ' ORDER BY c.created_at DESC LIMIT 200';
  res.json(db.prepare(q).all(...p));
});

app.post('/api/admin/commissions/payout', auth, adminOnly, (req, res) => {
  const { sellerId, commissionIds } = req.body;
  if (!sellerId && !commissionIds) return res.status(400).json({ error: 'sellerId or commissionIds required' });
  let result;
  if (commissionIds?.length) {
    const ph = commissionIds.map(() => '?').join(',');
    result = db.prepare(`UPDATE commissions SET status='paid',paid_at=datetime('now') WHERE id IN (${ph}) AND status='pending'`).run(...commissionIds);
  } else {
    result = db.prepare(`UPDATE commissions SET status='paid',paid_at=datetime('now') WHERE seller_id=? AND status='pending'`).run(sellerId);
  }
  res.json({ updated: result.changes });
});

app.post('/api/admin/commissions/payout-all', auth, adminOnly, (req, res) => {
  const result = db.prepare(`UPDATE commissions SET status='paid',paid_at=datetime('now') WHERE status='pending'`).run();
  res.json({ updated: result.changes });
});

app.get('/api/admin/reports/earnings', auth, adminOnly, (req, res) => {
  res.json({
    monthly: db.prepare(`SELECT strftime('%Y-%m',created_at) as month,COUNT(*) as sales,COALESCE(SUM(amount_ghc),0) as revenue,COALESCE(SUM(commission_ghc),0) as commissions_paid_direct FROM sales GROUP BY month ORDER BY month DESC LIMIT 24`).all(),
    byBook: db.prepare(`SELECT b.title,b.subtitle,b.cover_emoji,COUNT(s.id) as sales,COALESCE(SUM(s.amount_ghc),0) as revenue FROM sales s JOIN books b ON b.id=s.book_id GROUP BY s.book_id ORDER BY revenue DESC`).all(),
  });
});

app.get('/api/health', (_, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ── SPA fallback: all non-API routes serve index.html ──────────────────────
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(DIST, 'index.html'));
});

app.listen(PORT, () => console.log(`✦ Kamaleads running on port ${PORT}`));
