import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// On Render, use the persistent disk. Locally, use project folder.
const DB_PATH = process.env.NODE_ENV === 'production'
  ? '/data/kamaleads.db'
  : path.join(__dirname, 'kamaleads.db');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    password_hash TEXT NOT NULL,
    referral_code TEXT UNIQUE NOT NULL,
    referred_by TEXT,
    role TEXT DEFAULT 'seller',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (referred_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS books (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT,
    author TEXT NOT NULL,
    price_ghc REAL NOT NULL,
    commission_pct REAL NOT NULL DEFAULT 5.0,
    description TEXT,
    cover_emoji TEXT,
    active INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS sales (
    id TEXT PRIMARY KEY,
    seller_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    buyer_email TEXT,
    buyer_name TEXT,
    amount_ghc REAL NOT NULL,
    commission_ghc REAL NOT NULL,
    payment_ref TEXT,
    status TEXT DEFAULT 'completed',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
  );

  CREATE TABLE IF NOT EXISTS commissions (
    id TEXT PRIMARY KEY,
    seller_id TEXT NOT NULL,
    sale_id TEXT NOT NULL,
    level INTEGER NOT NULL,
    amount_ghc REAL NOT NULL,
    status TEXT DEFAULT 'pending',
    paid_at TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (sale_id) REFERENCES sales(id)
  );
`);

// Seed books
const bookCount = db.prepare('SELECT COUNT(*) as c FROM books').get().c;
if (bookCount === 0) {
  const ins = db.prepare(`INSERT INTO books (id,title,subtitle,author,price_ghc,commission_pct,description,cover_emoji) VALUES (?,?,?,?,?,?,?,?)`);
  ins.run('book-woman','Woman','The Hidden Treasure','Prophet Mark Kama',70,5,'Uncovering the priceless value, strength, and divine purpose of every woman.','💎');
  ins.run('book-man','Man','Built of Iron','Prophet Mark Kama',70,5,'Forging character, purpose, and divine strength in every man.','⚔️');
}

// Seed admin
const adminExists = db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
if (!adminExists) {
  const bcrypt = await import('bcryptjs');
  const hash = await bcrypt.default.hash('Admin1234!', 10);
  db.prepare(`INSERT INTO users (id,name,email,phone,password_hash,referral_code,role) VALUES (?,?,?,?,?,?,?)`)
    .run('admin-001','Prophet Mark Kama','admin@kamaleads.com','+233000000000',hash,'KAMA0001','admin');
  console.log('✦ Admin account created: admin@kamaleads.com / Admin1234!');
}

export default db;
